//
//  metalhelpApp.swift
//  metalhelp
//
//  Created by CEDAM 15  on 26/11/24.
//

import SwiftUI

@main
struct metalhelpApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
