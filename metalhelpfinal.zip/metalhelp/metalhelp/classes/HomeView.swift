import SwiftUI

struct HomeView: View {
    
    @State var suceso = ""
    @State private var sentir: String = ""
    @State var mostrar: Bool = false
    @State private var selectedEmotion: String? = nil
    @State var mostrarCard: Bool = false
    
    let emotionColors: [String: Color] = [
        "Feliz": .green,
        "Triste": .blue,
        "Enojado": .red,
        "Sorpresa": .pink,
        "Miedo": .gray,
        "Ansioso": .orange,
        "Desanimado": .gray,
        "Estresado": .brown,
        "Cansado": .purple
    ]
    
    var emociones = ["Feliz", "Triste", "Enojado", "Sorpresa", "Miedo", "Ansioso", "Desanimado", "Estresado", "Cansado"]
    
    var body: some View {
        VStack {
            HStack{
                TextField("¿Qué ha pasado hoy?", text: $suceso, onEditingChanged: { isEditing in
                    if isEditing {
                        withAnimation {
                            mostrar = true // Cambiar a true con transición
                        }
                    }
                })
                
                Image("icon")
                    .resizable()
                    .frame(width: 35, height: 35)
                    .cornerRadius(17)
                    .shadow(radius: 5)
            }
            // TextField con acción al hacer clic
            
            .textFieldStyle(RoundedBorderTextFieldStyle())
            .padding()
            
            // Espaciado dinámico
            Spacer()
            
            // Card que aparece con transición
            if mostrar {
                Text("¿Cómo me hizo sentir?")
                    .font(.headline)
                    .padding([.leading, .trailing])
                
                // Lista horizontal con las 5 emociones
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack(spacing: 20) {
                        ForEach(emociones, id: \.self) { emocion in
                            Button(action: {
                                selectedEmotion = emocion
                            }) {
                                Text(emocion)
                                    .padding()
                                    .background(selectedEmotion == emocion ? emotionColors[emocion] ?? Color.gray : Color.gray.opacity(0.3))
                                    .foregroundColor(.white)
                                    .cornerRadius(10)
                            }
                        }
                    }
                    .padding([.leading, .trailing])
                }
                .padding()
                
                HStack {
                    Button(action: {
                        // Acción del botón (por ejemplo, enviar texto)
                        withAnimation{
                            mostrar = false
                            mostrarCard = true
                        }
                        // Puedes agregar aquí cualquier lógica para el botón
                        sentir = "" // Limpiar el campo de texto después de enviar
                        
                    }) {
                        Image(systemName: "paperplane")
                            .fontWeight(.bold)
                            .foregroundColor(.white)
                            .padding()
                            .background(Color.blue)
                            .cornerRadius(10)
                            .shadow(radius: 5)
                            .padding(.trailing, 16) // Ajuste de la posición
                            .padding(.bottom, 16) // Ajuste de la posición
                    }
                }
                
                
            }
            
            ScrollView(){
                VStack(spacing: 20){
                    if mostrarCard {
                        CardView(titulo: "Fin de hackathon", feeling: "Ansioso", description: "Hoy se termina el hackathon y no se como nos pueda ir", profileImage: "")
                    }
                    
                    CardView(titulo: "Ansiedad académica", feeling: "Ansioso", description: "Me siento abrumado con las entregas y los exámenes.", profileImage: "")
                    CardView(titulo: "Falta de motivación", feeling: "Desanimado", description: "Últimamente me cuesta encontrar energía para estudiar.", profileImage: "")
                    CardView(titulo: "Estrés por desempeño", feeling: "Estresado", description: "Tengo miedo de no cumplir con las expectativas.", profileImage: "")
                    CardView(titulo: "Soledad", feeling: "Triste", description: "A veces siento que no tengo a nadie con quien hablar.", profileImage: "")
                    CardView(titulo: "Burnout", feeling: "Cansado", description: "Estoy agotado por la carga de trabajo y no puedo continuar.", profileImage: "")
                    
                    CardView(titulo: "Una gran noticia", feeling: "Feliz", description: "Recibí una oportunidad que cambiará mi vida.", profileImage: "")
                    CardView(titulo: "Examen difícil", feeling: "Miedo", description: "El examen fue más complicado de lo que esperaba.", profileImage: "")
                    CardView(titulo: "Día en el parque", feeling: "Sorpresa", description: "Un paseo inesperado me alegró el día.", profileImage: "")
                    CardView(titulo: "Meta alcanzada", feeling: "Feliz", description: "Finalmente logré el objetivo que me propuse.", profileImage: "")
                    
                    
                }
            }
            
        }
        .padding()
    }
    
    
    
    
}

#Preview {
    HomeView()
}
