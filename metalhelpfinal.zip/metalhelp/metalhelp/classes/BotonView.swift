import SwiftUI

struct BotonCall: View {
    @State var imagen = "phone"
    @State var texto = "emergencia"
    @State var texto2 = "911"
    
    var body: some View {
        Button(action: {
            // Acción que ocurre al presionar el botón
            print("Botón presionado")
        }) {
            VStack {
                Image(systemName: imagen)
                    .resizable()
                    .frame(width: 50, height: 50)
                    .foregroundStyle(.white)
                
                Text(texto)
                    .font(.title2)
                    .foregroundStyle(.white)
                    .bold()
                
                Text(texto2)
                    .font(.title3)
                    .bold()
                    .foregroundStyle(.white)
            }
            .frame(width: 200, height: 200)
            .background(.red)
            .cornerRadius(100)
            .shadow(radius: 10)
        }
    }
}

struct callsView: View {
    @State var imagen = "phone"
    @State var texto = "emergencia"
    @State var texto2 = "911"
    
    var body: some View {
        HStack(alignment: .center) {
            VStack {
                Image(systemName: imagen)
                    .resizable()
                    .frame(width: 20, height: 20)
                    .colorInvert()
            }
            .frame(width: 50, height: 50)
            .background(.red)
            .cornerRadius(25)
            .shadow(radius: 5)
            
            VStack {
                Text(texto)
                    .font(.title2)
                    .bold()
                Text(texto2)
                    .font(.title3)
                    .bold()
            }
            
            Text("20:00")
                .font(.title2)
        }
        .frame(width: 300, height: 65)
        .background(.white)
        .cornerRadius(20)
        .shadow(radius: 10)
        .padding(.horizontal)
        .padding()
    }
}

struct BotonView: View {
    var body: some View {
        
        VStack {
            BotonCall() // Botón de emergencia
            ScrollView{
                // Repetir callsView 5 veces
                ForEach(0..<9) { _ in
                    callsView()
                }
            }
        }
    }
}

#Preview {
    BotonView()
}
