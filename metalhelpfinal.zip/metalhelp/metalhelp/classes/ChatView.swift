import SwiftUI

struct heather: View {
    var body: some View {
        HStack(alignment: .center){
            Text("Chatcologo")
                .font(.title)
                .bold()
            Image(systemName: "phone")
                .resizable()
                .frame(width: 25, height: 25)
            Image(systemName: "video")
                .resizable()
                .frame(width: 25, height: 22)
            AsyncImage(url: URL(string: "https://picsum.photos/200"))
                .frame(width: 35, height: 35)
                .cornerRadius(17)
                .shadow(radius: 5)
        }
        .padding()
        .frame(width: .infinity, height: 50)
        .cornerRadius(10)
        .padding(.horizontal)
    }
}
struct MessageOutputView: View {
    var texto: String
    var hora: String
    var esUsuario: Bool
    
    var body: some View {
        VStack {
            HStack {
                if esUsuario {
                    Spacer() // Para alinear el mensaje del usuario a la derecha
                }
                
                Text(texto)
                    .padding()
                    .background(esUsuario ? Color.blue : Color.gray) // Color diferente según quien envíe el mensaje
                    .cornerRadius(10)
                    .foregroundColor(.white)
                    .frame(maxWidth: .infinity, alignment: esUsuario ? .trailing : .leading)
                
                if !esUsuario {
                    Spacer()
                }
            }
            
            HStack {
                if esUsuario {
                    Spacer() // Para alinear la hora del usuario a la derecha
                }
                
                Text(hora)
                    .font(.caption)
                    .foregroundColor(.black)
                    .frame(maxWidth: .infinity, alignment: esUsuario ? .trailing : .leading) // Alinea la hora a la derecha o izquierda según el usuario
            }
        }
        .padding(.horizontal)
    }
}


// Vista para ingresar el mensaje
struct MessageInputView: View {
    @State var texto = ""
    var body: some View {
        HStack(alignment: .bottom) {
            Image(systemName: "mic")
                .resizable()
                .frame(width: 25, height: 35)
            
            TextField("mensaje", text: $texto)
                .frame(height: 40)
                .keyboardType(.default)
                .background(.gray.opacity(0.1))
                .shadow(radius: 3)
                .cornerRadius(20)
            
            Image(systemName: "paperplane")
                .resizable()
                .frame(width: 35, height: 35)
        }
        .frame(height: 50)
        .padding()
    }
}

// Vista principal del chat
struct ChatView: View {
    var mensajes: [(texto: String, hora:String, esUsuario: Bool)] = [
        ("Hola, estoy triste porque hoy se termina el hackathon", "19:50", true),
        ("Hola, lamento escuchar que te sientes triste por el fin del hackathon", "20:00", false),
        ("Es completamente normal sentir esa tristeza cuando se acaba un proyecto o actividad en la que has invertido tiempo y esfuerzo. ", "20:02",  false),
        ("Te sugiero que tomes un momento para reflexionar sobre lo que lograste durante el evento. Reconoce tus esfuerzos y los aprendizajes que obtuviste. ", "20:03", false),
        
    ]
    
    var body: some View {
        
        VStack {
            heather()
            ScrollView{
                VStack(alignment: .leading, spacing: 10) {
                    ForEach(mensajes, id: \.texto) { mensaje in
                        MessageOutputView(texto: mensaje.texto, hora: mensaje.hora, esUsuario: mensaje.esUsuario)
                    }
                }
            }
            MessageInputView()
        }
        
    }
}

#Preview {
    ChatView()
}

