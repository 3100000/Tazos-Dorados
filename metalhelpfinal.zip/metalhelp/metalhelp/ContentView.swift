import SwiftUI

struct ContentView: View {
    @State var seleccionada = 1

    var body: some View {
        TabView(selection: $seleccionada){
            
            ChatView()
                .tabItem{
                    Image(systemName: "message.fill")
                }.tag(0)
            
            HomeView()
                .tabItem{
                    Image(systemName: "house.fill")
                }.tag(1)
            
            BotonView()
                .tabItem{
                    Image(systemName: "bell.fill")
                }.tag(2)
        }
    }
}

#Preview {
    ContentView()
}
