////
////  ModelListCards.swift
////  metalhelp
////
////  Created by CEDAM 15  on 26/11/24.
//
//let cardlist = [
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: ""),
//    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: "")
//]


