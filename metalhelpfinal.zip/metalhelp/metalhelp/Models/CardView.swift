import SwiftUI
import Foundation


struct CardView: View {
    var titulo: String
    var feeling: String
    var description: String
    var profileImage: String
    
    
    
    
    let emotionColors: [String: Color] = [
        "Feliz": .green,
        "Triste": .blue,
        "Enojado": .red,
        "Sorpresa": .pink,
        "Miedo": .gray,
        "Ansioso": .orange,
        "Desanimado": .gray,
        "Estresado": .brown,
        "Cansado": .purple
    ]
    
    
    
    var body: some View {
        VStack(alignment: .leading) {
            
            HStack {
                
                AsyncImage(url: URL(string: "https://picsum.photos/200"))
                    .frame(width: 45, height: 45)
                    .cornerRadius(25)
                    .shadow(radius: 8)
                
                VStack(alignment: .leading, spacing: 2) {
                    HStack{
                        Text(titulo)
                            .font(.headline)
                        
                        colorearemociones(from: feeling)
                    }
                    Text("Fecha: \(formattedDate())")
                        .font(.footnote)
                        .foregroundColor(.gray)
                    
                }
                
                Spacer()
                
                Button(action: {
                    print("Opciones seleccionadas")
                }) {
                    Image(systemName: "ellipsis")
                        .font(.title3)
                        .foregroundColor(.gray)
                }
            }
            .padding([.leading, .trailing, .top])
            
            
            Text(description)
                .font(.body)
                .padding([.leading, .trailing, .bottom])
                .foregroundColor(.black)
            
            
            HStack {
                Spacer()
                VStack {
                    Button(action: hablarlo) {
                        HStack(spacing: 5) { // Reduce el espacio entre el texto y el ícono
                            Text("Quiero hablarlo")
                                .font(.footnote) // Fuente más pequeña
                            Image(systemName: "arrow.up")
                                .font(.system(size: 14)) // Ícono más pequeño
                        }
                        .padding(6) // Reduce el relleno interno
                        .background(Color.purple)
                        .foregroundColor(.white)
                        .cornerRadius(8) // Esquinas más redondeadas para el tamaño reducido
                    }
                    .padding() // Relleno externo ajustado
                }
                
            }
            
            
        }
        .background(Color.white)
        .cornerRadius(15)
        .shadow(color: .gray.opacity(0.3), radius: 5, x: 0, y: 5)
        .padding(.horizontal)
    }
    
    func hablarlo(){
    }
    
    // Función para formatear la fecha
    func formattedDate() -> String {
        let dateFormatter = DateFormatter()
        dateFormatter.dateStyle = .short
        dateFormatter.timeStyle = .none
        return dateFormatter.string(from: Date())
    }
    
    
    func colorearemociones(from feeling: String) -> some View {
        // Diccionario para mapear emociones
        let emotionMapping: [String: String] = [
            "Sad": "Triste",
            "Happy": "Feliz",
            "Angry": "Enojado",
            "Surprised": "Sorpresa",
            "Fear": "Miedo"
        ]
        
        // Intentar traducir la emoción
        let translatedFeeling = emotionMapping[feeling] ?? feeling
        
        return HStack {
            if let color = emotionColors[translatedFeeling] {
                Text(translatedFeeling)
                    .font(.subheadline)
                    .padding(.horizontal, 8)
                    .padding(.vertical, 4)
                    .background(color.opacity(0.3))
                    .foregroundColor(color)
                    .cornerRadius(8)
            } else {
                Text(translatedFeeling)
                    .font(.subheadline)
                    .foregroundColor(.gray)
            }
        }
    }
}

#Preview {
    CardView(titulo: "Fin de hackathon", feeling: "Sad", description: "Hoy se termina el hackathon", profileImage: "")
}
