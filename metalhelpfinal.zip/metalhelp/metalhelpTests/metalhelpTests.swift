//
//  metalhelpTests.swift
//  metalhelpTests
//
//  Created by CEDAM 15  on 26/11/24.
//

import Testing
@testable import metalhelp

struct metalhelpTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
